<?php
	include 'database.php';
    //$base_url = "http://localhost/shoppingproject-yb/";
     $base_url = "https://asetechnologies.in/projects/shopping3/";
    

?>
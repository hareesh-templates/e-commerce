<?php
  include 'admin/php_files/database.php';

  // $hostname = "http://localhost/shoppingproject-yb";
  $hostname = "https://asetechnologies.in/projects/shopping3/";
    
?>